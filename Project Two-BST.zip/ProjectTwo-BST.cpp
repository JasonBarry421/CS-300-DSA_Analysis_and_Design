//============================================================================
// Name        : ProjectTwo-BST.cpp
// Author      : Jason Barry
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<algorithm>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

//Internal structure for course node
struct Course {
    string courseNum;   //unique identifier
    string courseName;
    string preReq1;
    string preReq2;
    
    Course* left;
    Course* right;

    //default constructor
    Course() {
        left = nullptr;
        right = nullptr;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

class BinarySearchTree {
private:
    Course* root;
    void addNode(Course* node, Course* course);
public:
    BinarySearchTree();
    void inOrder();
    void inOrderHelper(Course* node);
    void Insert(Course* course);
    void Search(string courseKey);
};



//============================================================================
// Function Declarations
//============================================================================

void printCourseInfo(Course* course);
vector<Course> vectorOfCourses(BinarySearchTree* bst);


//============================================================================
// Defauly Constructor
//============================================================================

BinarySearchTree::BinarySearchTree() {
    // initialize housekeeping variables
    //root is equal to nullptr
    root = nullptr;
}

//============================================================================
// Used to Traverse the tree in order
//============================================================================

void BinarySearchTree::inOrder() {
    // In order root
    // call inOrder fuction and pass root 
    inOrderHelper(root);
}


void BinarySearchTree::inOrderHelper(Course* course) {
    //if node is not equal to null ptr
    if (course != nullptr) {
        // InOrder node left
        inOrderHelper(course->left);

        // InOrder node right
        inOrderHelper(course->right);
    }
}

//============================================================================
// Used to Insert a new Course
//============================================================================

void BinarySearchTree::Insert(Course* course) {
    // if root equal to null ptr
    if (root == nullptr) {
        // root is equal to new node bid
        root = course;
    }
    // else
    else {
        // add course node root and bid
        this->addNode(root, course);
    }
}

void BinarySearchTree::addNode(Course* node, Course* course) {
    //If node is larger than, add to left
    if (node != nullptr && node->courseNum.compare(course->courseNum) > 0) {
        // if no left node
        if (node->left == nullptr) {
            // this node becomes left
            node->left = new Course();
            return;
        }
        // else
        else {
            // recurse down the left node
            this->addNode(node->left, course);
        }
    }
    // Else if node is less than, add to right
    else if (node != nullptr && node->courseNum.compare(course->courseNum) < 0) {
        // if no right node
        if (node->right == nullptr) {
            // this node becomes right
            node->right = new Course();
            return;
        }
        // else
        else {
            // recurse down the right node
            this->addNode(node->right, course);
        }
    }
}

// ===========================================================================
// Function for Parsing Courses
//============================================================================

Course* parseCourse(string line) {
    //Creates new Course object
    Course* course = new Course;

    //Used to find each comma in line
    size_t commaPos1 = line.find(",");
    size_t commaPos2 = line.find(",", commaPos1 + 1);
    size_t commaPos3 = line.find(",", commaPos2 + 1);
    size_t commaPos4 = line.find(",", '\n');

    //Stores line from 0 to first comma in courseNum
    course->courseNum = line.substr(0, commaPos1);

    //Stores line from first comma to second comma in courseName
    course->courseName = line.substr(commaPos1 + 1, commaPos2 - commaPos1 - 1);

    //Stores line from second comma to third comma in preReq1
    course->preReq1 = line.substr(commaPos2 + 1, commaPos3 - commaPos2 - 1);
    
    //if preReq1 already equal to courseNum
    if (course->preReq1 == course->courseNum) {
        //Sets preReq1 to an empty string
        course->preReq1 = "";
    }

    //Stores line from third comma to fourth comma in preReq2
    course->preReq2 = line.substr(commaPos3 + 1, commaPos4 - commaPos3 - commaPos2 - 1);

    //if preReq2 already equal to courseNum OR courseName OR preReq1
    if (course->preReq2 == course->courseName || course->preReq2 == course->courseNum || course->preReq2 == course->preReq1) {
        //Sets preReq2 to an empty string
        course->preReq2 = "";
    }

    //push this course to the end
    return course;
}


//============================================================================
// Searches for a Specific Course
//============================================================================

void BinarySearchTree::Search(string courseKey) {
    // set current node equal to root
    Course* curCourseNode = root;

    // keep looping downwards until bottom reached or matching courseNum found
    while (curCourseNode != nullptr) {

        // if match found
        if (curCourseNode->courseNum == courseKey) {
            printCourseInfo(curCourseNode);
            break;
        }

        // if the currentNode is larger than the courseKey
        else if (curCourseNode->courseNum > courseKey) {
            // then traverse left
            curCourseNode = curCourseNode->left;
        }
        // else
        else {
            // traverse right
            curCourseNode = curCourseNode->right;
        }
    }
}

//============================================================================
// Sorts Vector of Courses based on InOrder Traversal
//============================================================================

vector<Course> vectorOfCourses(BinarySearchTree* bst) {
    // Create a vector to store the courses
    vector<Course> courseVector;

    //Declares variables
    ifstream inputFile;
    string line;

    //Opens .txt file
    inputFile.open("courseInfo.txt");

    //While not end of file
    while (!inputFile.eof()) {
        //get line in file
        getline(inputFile, line);

        //Parse line
        bst->Insert(parseCourse(line));

        //Sort Courses
        bst->inOrderHelper(parseCourse(line));

        //Store Course in courseVector
        Course* course = parseCourse(line);
        courseVector.push_back(*course);
    }
    //Close File
    inputFile.close();

    return courseVector;
}

//============================================================================
// Printing the entire List of Course's Information
//============================================================================

void printCourseList(BinarySearchTree* bst) {
    vector<Course> courseVector;

    courseVector = vectorOfCourses(bst);

    // Sort the vector in alphanumeric order
    sort(courseVector.begin(), courseVector.end(), [](const Course& a, const Course& b) {
        return a.courseNum < b.courseNum;
    });

    // Print the sorted list of courses
    for (Course& course : courseVector) {
        printCourseInfo(&course);
    }
}


//============================================================================
// Printing a specific Course's information Functions
//============================================================================

void printCourseInfo(Course* course) {
    //Output courseNum and courseName
    cout << course->courseNum << ", " << course->courseName;

    //If preReq1 isn't an empty string (i.e. There is at least one prerequisite)
    if (course->preReq1 != "") {
        //Output preReq1
        cout << ", " << course->preReq1;
    }
    //If preReq2 isn't an empty string (i.e. There is at least two prerequisites)
    if (course->preReq2 != "") {
        //Output preReq2
        cout << ", " << course->preReq2;
    }
    cout << endl;
}

//============================================================================
// Main Method which includes function to Display the Menu
//============================================================================

int main(int argc, char* argv[]) {

    // process command line arguments
    string courseKey = "MATH201";

    // Define a binary search tree to hold all courses
    BinarySearchTree* courseBST;
    courseBST = new BinarySearchTree();
    Course* course;

    int choice = 0;
    while (choice != 9) {
            cout << "Menu:" << endl;
            cout << "  1. Load Data Structure" << endl;
            cout << "  2. Print Course List" << endl;
            cout << "  3. Print Course" << endl;
            cout << "  9. Exit" << endl;
            cout << "Enter choice: ";
            cin >> choice;

            switch (choice) {
            case 1: {
                // method call to load the courses
                vectorOfCourses(courseBST);
                cout << endl;
                break;
            }
            case 2: {
                cout << endl;
                //Method call to print list
                printCourseList(courseBST);
                cout << endl << endl;
                break;
            }
            case 3: {
                cout << "\n";
                //Method call to search list
                courseBST->Search(courseKey);
                cout << endl;
                break;
            }
            case 9: {
                cout << "\nGoodbye....\n";
                break;
            }
            default: {
                cout << "\n"<< choice << " is an invalid choice.\n\n";
                break;
            }
        }
    }
}